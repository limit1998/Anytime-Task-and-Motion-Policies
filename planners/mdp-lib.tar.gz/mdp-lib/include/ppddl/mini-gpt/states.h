#ifdef FULL_STATES
#  include "full_states.h"
#endif

#ifdef ATOM_STATES
#  include "atom_states.h"
#endif
