#include "../../include/domains/DummyState.h"

std::ostream& DummyState::print(std::ostream& os) const
{
    os << "Dummy State";
}
